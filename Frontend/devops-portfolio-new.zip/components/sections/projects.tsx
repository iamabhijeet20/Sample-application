import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const projects = [
  {
    name: "EKS with Terraform",
    desc: "Modular Terraform setup for AWS VPC + EKS with managed node groups, IRSA, and GitHub OIDC.",
    tags: ["AWS", "Terraform", "EKS", "IRSA"],
    href: "https://github.com/your-username/eks-terraform",
  },
  {
    name: "GitHub Actions CI/CD",
    desc: "Multi-stage pipeline with caching, test matrix, SAST, container scanning, and preview deployments.",
    tags: ["GitHub Actions", "Docker", "Trivy", "Snyk"],
    href: "https://github.com/your-username/gha-cicd",
  },
  {
    name: "Observability Stack",
    desc: "Prometheus, Grafana, Loki, and Alertmanager on k3s with Helm charts and dashboards for services.",
    tags: ["Prometheus", "Grafana", "Loki", "Helm"],
    href: "https://github.com/your-username/observability-stack",
  },
]

export function Projects() {
  return (
    <section id="projects" aria-labelledby="projects-heading" className="border-b">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <h2 id="projects-heading" className="text-3xl font-semibold tracking-tight">
          Projects
        </h2>
        <p className="mt-2 text-muted-foreground leading-relaxed">
          Selected work demonstrating automation, infrastructure as code, and operational insight.
        </p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Card key={p.name} className="flex flex-col">
              <CardHeader>
                <CardTitle className="text-lg">{p.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-muted-foreground leading-relaxed">{p.desc}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <Badge key={t} variant="secondary" className="px-2 py-1">
                      {t}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild size="sm">
                  <a href={p.href} target="_blank" rel="noopener noreferrer" aria-label={`Open ${p.name} on GitHub`}>
                    View Repo
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
