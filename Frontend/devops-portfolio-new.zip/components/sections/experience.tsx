import { Briefcase } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const roles = [
  {
    company: "Acme Corp",
    title: "DevOps Engineer",
    period: "2023 — Present",
    bullets: [
      "Designed GitHub Actions workflows with caching and preview deployments, cutting build times by ~35%.",
      "Provisioned AWS infra via Terraform (VPC, EKS, IAM), with environment isolation and remote state.",
      "Implemented Prometheus + Grafana dashboards and alerting for core services, reducing MTTR.",
    ],
  },
  {
    company: "Startup Labs",
    title: "Junior DevOps Engineer",
    period: "2022 — 2023",
    bullets: [
      "Containerized services with Docker and multi-stage builds, standardizing dev/prod parity.",
      "Added IaC modules and CI checks for policy compliance (fmt, validate, tflint).",
      "Collaborated with developers to bake SAST and image scanning into pipelines.",
    ],
  },
]

export function Experience() {
  return (
    <section id="experience" aria-labelledby="experience-heading" className="border-b bg-card">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="flex items-center gap-3">
          <Briefcase aria-hidden className="h-5 w-5 text-primary" />
          <h2 id="experience-heading" className="text-3xl font-semibold tracking-tight">
            Experience
          </h2>
        </div>
        <p className="mt-2 text-muted-foreground leading-relaxed">
          Hands-on with CI/CD, Terraform, containers, and Kubernetes in production environments.
        </p>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {roles.map((role) => (
            <Card key={role.company}>
              <CardHeader>
                <CardTitle className="text-lg">
                  {role.title} · {role.company}
                </CardTitle>
                <p className="text-sm text-muted-foreground">{role.period}</p>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 leading-relaxed">
                  {role.bullets.map((b) => (
                    <li key={b}>{b}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
