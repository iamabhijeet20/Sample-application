import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const skillGroups = [
  {
    title: "Cloud & Infra",
    items: ["AWS", "EC2", "VPC", "EKS", "Docker", "Kubernetes", "Terraform", "Linux"],
  },
  {
    title: "CI/CD",
    items: ["GitHub Actions", "Jenkins", "Argo CD", "Docker Buildx", "Release Automation"],
  },
  {
    title: "Observability",
    items: ["Prometheus", "Grafana", "Loki", "ELK", "Alertmanager", "OpenTelemetry (basics)"],
  },
  {
    title: "Scripting",
    items: ["Bash", "Python", "YAML", "Make", "Helm"],
  },
  {
    title: "Security",
    items: ["IAM (basics)", "Snyk", "Trivy", "Secrets Management"],
  },
]

export function Skills() {
  return (
    <section id="skills" aria-labelledby="skills-heading" className="border-b">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <h2 id="skills-heading" className="text-3xl font-semibold tracking-tight">
          Skills & Tools
        </h2>
        <p className="mt-2 text-muted-foreground leading-relaxed">
          A pragmatic toolkit focused on automation, reliability, and speed to production.
        </p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {skillGroups.map((group) => (
            <Card key={group.title}>
              <CardHeader>
                <CardTitle className="text-lg">{group.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <Badge key={item} variant="secondary" className="px-2 py-1">
                      {item}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
