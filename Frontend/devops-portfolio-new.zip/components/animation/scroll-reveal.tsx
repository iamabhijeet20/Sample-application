"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"
import type { JSX as ReactJSX } from "react"

type Props = {
  as?: keyof ReactJSX.IntrinsicElements
  className?: string
  children: React.ReactNode
  delay?: number
}

export function ScrollReveal({ as: Tag = "div", className, children, delay = 0 }: Props) {
  const ref = useRef<HTMLElement | null>(null as any)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (typeof window === "undefined") return
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVisible(true)
      return
    }
    const el = ref.current as Element | null
    if (!el) return
    const obs = new IntersectionObserver(
      (entries) => {
        const entry = entries[0]
        if (entry.isIntersecting) {
          // small timeout to stagger elements
          const id = window.setTimeout(() => setVisible(true), delay)
          return () => window.clearTimeout(id)
        }
      },
      { threshold: 0.2 },
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [delay])

  return (
    <Tag
      ref={ref as any}
      className={cn(
        "transition-all duration-700 ease-out will-change-transform",
        visible ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-4 scale-[0.995]",
        className,
      )}
    >
      {children}
    </Tag>
  )
}
